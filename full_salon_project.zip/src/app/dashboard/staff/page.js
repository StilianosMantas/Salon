
export default function StaffPage() {
  return <h2>Manage Staff</h2>
}
