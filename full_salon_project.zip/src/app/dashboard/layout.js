
import Link from 'next/link'
export default function DashboardLayout({ children }) {
  return (
    <div style={{ display: 'flex' }}>
      <aside style={{ width: 200 }}>
        <nav>
          <Link href="/dashboard">Overview</Link><br />
          <Link href="/dashboard/staff">Staff</Link><br />
          <Link href="/dashboard/clients">Clients</Link><br />
          <Link href="/dashboard/services">Services</Link><br />
          <Link href="/dashboard/slots">Slots</Link>
        </nav>
      </aside>
      <main style={{ marginLeft: 20 }}>{children}</main>
    </div>
  )
}
