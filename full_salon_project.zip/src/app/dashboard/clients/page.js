
export default function ClientsPage() {
  return <h2>Manage Clients</h2>
}
