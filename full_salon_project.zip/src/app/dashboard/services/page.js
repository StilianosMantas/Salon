
export default function ServicesPage() {
  return <h2>Manage Services</h2>
}
