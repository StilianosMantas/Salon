
export default function DashboardHome() {
  return <h2>Salon Dashboard Overview</h2>
}
