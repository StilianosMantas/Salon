
export default function SlotsPage() {
  return <h2>Manage Slots</h2>
}
