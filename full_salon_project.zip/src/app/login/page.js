
'use client'
import { useState } from 'react'
import { supabase } from '@/lib/supabaseClient'
import { useRouter } from 'next/navigation'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const router = useRouter()

  async function login(e) {
    e.preventDefault()
    await supabase.auth.signInWithOtp({ email })
    alert('Check your email for the login link!')
  }

  return (
    <form onSubmit={login}>
      <h2>Login</h2>
      <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email" required />
      <button type="submit">Send Magic Link</button>
    </form>
  )
}
